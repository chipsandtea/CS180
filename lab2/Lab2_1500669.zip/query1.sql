-- Lab 2, Query 1
-- Find the names and SSN for persons whose salary is more than 20,000.

SELECT Name, SSN
FROM Persons
WHERE Salary > 20000;

