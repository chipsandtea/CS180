\i create_Lab3.sql
\i load_values_Lab3.sql
\i merge.sql
\i foreign.sql
\i general.sql
