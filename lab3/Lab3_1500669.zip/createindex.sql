-- 2.7 Create an index

CREATE INDEX person_houseid_aptnum_index
ON Persons (HouseID, ApartmentNumber);
